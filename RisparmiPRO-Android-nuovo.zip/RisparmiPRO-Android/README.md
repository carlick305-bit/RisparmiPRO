# Risparmi PRO – progetto Android

App Android con interfaccia locale in WebView. La gestione dei dati è offline e utilizza lo storage locale dell'app.

## Funzioni incluse
- Due fondi separati: **reale** e **virtuale**.
- Ogni fondo gestisce separatamente contanti e carta bancaria.
- Entrate, uscite e trasferimenti tra contanti e carta.
- Trasferimenti senza doppio conteggio e senza commissioni.
- Commissione simulata dello 0,2% sulle uscite registrate sulla carta, mostrata prima della conferma e inclusa nell'addebito.
- Riepilogo generale: contanti totali, carte totali, patrimonio complessivo e obiettivi mensili/annuali.
- Avanzamento degli obiettivi calcolato sulle entrate del fondo reale.
- Cronologia, esportazione e importazione del backup JSON.

## Creare l'APK
1. Aprire questa cartella in Android Studio.
2. Attendere la sincronizzazione Gradle e l'installazione di Android SDK 35, se richiesti.
3. Selezionare **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Il file debug sarà in `app/build/outputs/apk/debug/app-debug.apk`.

È presente il workflow `.github/workflows/build-apk.yml` per generare un APK debug su GitHub Actions. Dopo aver caricato il progetto in un repository GitHub, avviare l'azione **Build Risparmi PRO APK** da Actions; il file APK sarà disponibile come artifact.

## Stato della compilazione
Questo archivio contiene il progetto sorgente completo, non un APK già compilato. Nell'ambiente di preparazione non sono installati Android SDK e Gradle, quindi non è possibile generare e verificare qui il binario APK. Non installare APK provenienti da fonti non attendibili.
